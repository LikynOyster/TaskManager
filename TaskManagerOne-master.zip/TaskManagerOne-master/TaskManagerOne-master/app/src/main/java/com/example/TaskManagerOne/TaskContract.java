package com.example.TaskManagerOne;

import android.database.Cursor;
import android.net.Uri;
import android.provider.BaseColumns;

public class TaskContract {
    //Database schema information
    public static final String TABLE_TASK = "tasks";
    /*sort order constant*/
    //priority first,Completed last,the rest by date
    public static final String DEFAULT_SORT = String.format("%s ASC ,%s DESC , %sASC",
            TaskColumns.IS_COMPLETE, TaskColumns.IS_PROGRESS, TaskColumns.IS_OVERDUE);
    //Complete last,then by date, followed by priority
    public static final String DATE_SORT = String.format("%s ASC , %s ASC ,%s DESC",
            TaskColumns.IS_COMPLETE,  TaskColumns.IS_OVERDUE, TaskColumns.IS_PROGRESS);

    //Base content Uri for accessing the provider
    public static final Uri CONTENT_URI = new Uri.Builder().scheme("content")
            .authority(CONTENT_AUTHORITY)
            .appendPath(TABLE_TASKS)
            .build();

    /* Helpers to retrieve column values */
    public static String getColumnString(Cursor cursor, String columnName) {
        return cursor.getString( cursor.getColumnIndex(columnName) );
    }

    public static int getColumnInt(Cursor cursor, String columnName) {
        return cursor.getInt( cursor.getColumnIndex(columnName) );
    }

    public static long getColumnLong(Cursor cursor, String columnName) {
        return cursor.getLong( cursor.getColumnIndex(columnName) );
    }



    public static final class TaskColumns implements BaseColumns {

        public static final String DESCRIPTION = "description";

        public static final String IS_COMPLETE = "is_complete";

        public static final String IS_PRIORITY = "is_priority";

        public static final String DUE_DATE = "due_date";
    }


}
